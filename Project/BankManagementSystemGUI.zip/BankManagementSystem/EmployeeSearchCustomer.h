#pragma once

namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for EmployeeSearchCustomer
	/// </summary>
	public ref class EmployeeSearchCustomer : public System::Windows::Forms::Form
	{
	public:
		EmployeeSearchCustomer(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~EmployeeSearchCustomer()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ button1;
	protected:
	private: System::Windows::Forms::Label^ label7;
	private: System::Windows::Forms::TextBox^ textBox1;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ textBoxCustomerBalance;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::ComboBox^ comboBoxCustomerBankType;
	private: System::Windows::Forms::ComboBox^ comboBoxCustomerGender;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::TextBox^ textBoxCustomerMobileNumber;
	private: System::Windows::Forms::TextBox^ textBoxCustomerAccountNo;
	private: System::Windows::Forms::TextBox^ textBoxCustomerName;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label8;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeSearch;
	private: System::Windows::Forms::Label^ label9;
	private: System::Windows::Forms::PictureBox^ pictureBox1;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(EmployeeSearchCustomer::typeid));
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBoxCustomerBalance = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->comboBoxCustomerBankType = (gcnew System::Windows::Forms::ComboBox());
			this->comboBoxCustomerGender = (gcnew System::Windows::Forms::ComboBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBoxCustomerMobileNumber = (gcnew System::Windows::Forms::TextBox());
			this->textBoxCustomerAccountNo = (gcnew System::Windows::Forms::TextBox());
			this->textBoxCustomerName = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->textBoxEmployeeSearch = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(12, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(86, 42);
			this->button1->TabIndex = 52;
			this->button1->Text = L"Back";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &EmployeeSearchCustomer::button1_Click);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label7->Location = System::Drawing::Point(20, 294);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(39, 16);
			this->label7->TabIndex = 51;
			this->label7->Text = L"CNIC";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(23, 315);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(203, 20);
			this->textBox1->TabIndex = 50;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(353, 235);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(55, 16);
			this->label5->TabIndex = 49;
			this->label5->Text = L"Balance";
			// 
			// textBoxCustomerBalance
			// 
			this->textBoxCustomerBalance->Location = System::Drawing::Point(356, 256);
			this->textBoxCustomerBalance->Name = L"textBoxCustomerBalance";
			this->textBoxCustomerBalance->Size = System::Drawing::Size(203, 20);
			this->textBoxCustomerBalance->TabIndex = 48;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(353, 178);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(94, 16);
			this->label4->TabIndex = 47;
			this->label4->Text = L"Account Type";
			// 
			// comboBoxCustomerBankType
			// 
			this->comboBoxCustomerBankType->Font = (gcnew System::Drawing::Font(L"Georgia", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBoxCustomerBankType->FormattingEnabled = true;
			this->comboBoxCustomerBankType->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Saving", L"Current" });
			this->comboBoxCustomerBankType->Location = System::Drawing::Point(356, 197);
			this->comboBoxCustomerBankType->Name = L"comboBoxCustomerBankType";
			this->comboBoxCustomerBankType->Size = System::Drawing::Size(203, 22);
			this->comboBoxCustomerBankType->TabIndex = 46;
			// 
			// comboBoxCustomerGender
			// 
			this->comboBoxCustomerGender->Font = (gcnew System::Drawing::Font(L"Georgia", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBoxCustomerGender->FormattingEnabled = true;
			this->comboBoxCustomerGender->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Male", L"Female" });
			this->comboBoxCustomerGender->Location = System::Drawing::Point(23, 254);
			this->comboBoxCustomerGender->Name = L"comboBoxCustomerGender";
			this->comboBoxCustomerGender->Size = System::Drawing::Size(203, 22);
			this->comboBoxCustomerGender->TabIndex = 43;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(20, 235);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(52, 16);
			this->label6->TabIndex = 42;
			this->label6->Text = L"Gender";
			// 
			// textBoxCustomerMobileNumber
			// 
			this->textBoxCustomerMobileNumber->Location = System::Drawing::Point(356, 145);
			this->textBoxCustomerMobileNumber->Name = L"textBoxCustomerMobileNumber";
			this->textBoxCustomerMobileNumber->Size = System::Drawing::Size(203, 20);
			this->textBoxCustomerMobileNumber->TabIndex = 41;
			// 
			// textBoxCustomerAccountNo
			// 
			this->textBoxCustomerAccountNo->Location = System::Drawing::Point(24, 197);
			this->textBoxCustomerAccountNo->Name = L"textBoxCustomerAccountNo";
			this->textBoxCustomerAccountNo->Size = System::Drawing::Size(203, 20);
			this->textBoxCustomerAccountNo->TabIndex = 40;
			// 
			// textBoxCustomerName
			// 
			this->textBoxCustomerName->Location = System::Drawing::Point(23, 145);
			this->textBoxCustomerName->Name = L"textBoxCustomerName";
			this->textBoxCustomerName->Size = System::Drawing::Size(203, 20);
			this->textBoxCustomerName->TabIndex = 39;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(353, 126);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(104, 16);
			this->label3->TabIndex = 38;
			this->label3->Text = L"Mobile Number";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(25, 178);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(114, 16);
			this->label2->TabIndex = 37;
			this->label2->Text = L"Account Number";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(21, 126);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(106, 16);
			this->label1->TabIndex = 36;
			this->label1->Text = L"Customer Name";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->BackColor = System::Drawing::SystemColors::Menu;
			this->label8->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label8->Location = System::Drawing::Point(359, 87);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(63, 15);
			this->label8->TabIndex = 55;
			this->label8->Text = L"Search ID";
			// 
			// textBoxEmployeeSearch
			// 
			this->textBoxEmployeeSearch->BackColor = System::Drawing::SystemColors::MenuBar;
			this->textBoxEmployeeSearch->Location = System::Drawing::Point(209, 85);
			this->textBoxEmployeeSearch->Name = L"textBoxEmployeeSearch";
			this->textBoxEmployeeSearch->Size = System::Drawing::Size(213, 20);
			this->textBoxEmployeeSearch->TabIndex = 54;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Font = (gcnew System::Drawing::Font(L"Georgia", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label9->Location = System::Drawing::Point(437, 8);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(148, 14);
			this->label9->TabIndex = 53;
			this->label9->Text = L"Search Customer Details";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(209, 8);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(200, 59);
			this->pictureBox1->TabIndex = 56;
			this->pictureBox1->TabStop = false;
			// 
			// EmployeeSearchCustomer
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(582, 372);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->textBoxEmployeeSearch);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->textBoxCustomerBalance);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->comboBoxCustomerBankType);
			this->Controls->Add(this->comboBoxCustomerGender);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBoxCustomerMobileNumber);
			this->Controls->Add(this->textBoxCustomerAccountNo);
			this->Controls->Add(this->textBoxCustomerName);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"EmployeeSearchCustomer";
			this->Text = L"EmployeeSearchCustomer";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		this->Close();
	}
};
}
