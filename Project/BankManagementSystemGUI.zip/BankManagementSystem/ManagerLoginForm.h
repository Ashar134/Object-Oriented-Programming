#pragma once
#include "ManagerHomePage.h"
namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for ManagerLoginForm
	/// </summary>
	public ref class ManagerLoginForm : public System::Windows::Forms::Form
	{
	public:
		ManagerLoginForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ManagerLoginForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::TextBox^ textBoxManagerUsername;
	private: System::Windows::Forms::TextBox^ textBoxManagerPassword;
	private: System::Windows::Forms::Button^ buttonManagerLogin;






	protected:

	private:
		String^ userName = "admin";
		String^ password = "admin123";   //Default Manager login bcz bank has one manager
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(ManagerLoginForm::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->textBoxManagerUsername = (gcnew System::Windows::Forms::TextBox());
			this->textBoxManagerPassword = (gcnew System::Windows::Forms::TextBox());
			this->buttonManagerLogin = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(-9, 0);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(385, 76);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 2;
			this->pictureBox1->TabStop = false;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(72, 111);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(0, 13);
			this->label1->TabIndex = 3;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(57, 124);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(82, 16);
			this->label2->TabIndex = 4;
			this->label2->Text = L"User Name :";
			this->label2->Click += gcnew System::EventHandler(this, &ManagerLoginForm::label2_Click_1);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(57, 160);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(73, 16);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Password :";
			this->label3->Click += gcnew System::EventHandler(this, &ManagerLoginForm::label3_Click);
			// 
			// textBoxManagerUsername
			// 
			this->textBoxManagerUsername->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->textBoxManagerUsername->Location = System::Drawing::Point(157, 123);
			this->textBoxManagerUsername->Name = L"textBoxManagerUsername";
			this->textBoxManagerUsername->Size = System::Drawing::Size(122, 20);
			this->textBoxManagerUsername->TabIndex = 6;
			this->textBoxManagerUsername->TextChanged += gcnew System::EventHandler(this, &ManagerLoginForm::textBox1ManagerUsername_TextChanged);
			// 
			// textBoxManagerPassword
			// 
			this->textBoxManagerPassword->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->textBoxManagerPassword->Location = System::Drawing::Point(157, 160);
			this->textBoxManagerPassword->Name = L"textBoxManagerPassword";
			this->textBoxManagerPassword->PasswordChar = '*';
			this->textBoxManagerPassword->Size = System::Drawing::Size(122, 20);
			this->textBoxManagerPassword->TabIndex = 7;
			this->textBoxManagerPassword->TextChanged += gcnew System::EventHandler(this, &ManagerLoginForm::textBox1_TextChanged);
			// 
			// buttonManagerLogin
			// 
			this->buttonManagerLogin->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->buttonManagerLogin->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonManagerLogin->Location = System::Drawing::Point(171, 202);
			this->buttonManagerLogin->Name = L"buttonManagerLogin";
			this->buttonManagerLogin->Size = System::Drawing::Size(65, 26);
			this->buttonManagerLogin->TabIndex = 8;
			this->buttonManagerLogin->Text = L"Login";
			this->buttonManagerLogin->UseVisualStyleBackColor = false;
			this->buttonManagerLogin->Click += gcnew System::EventHandler(this, &ManagerLoginForm::buttonManagerLogin_Click);
			// 
			// ManagerLoginForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(374, 295);
			this->Controls->Add(this->buttonManagerLogin);
			this->Controls->Add(this->textBoxManagerPassword);
			this->Controls->Add(this->textBoxManagerUsername);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"ManagerLoginForm";
			this->Text = L"ManagerLoginForm";
			this->Load += gcnew System::EventHandler(this, &ManagerLoginForm::ManagerLoginForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label2_Click_1(System::Object^ sender, System::EventArgs^ e) {
	}
	private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBox1_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void textBox1ManagerUsername_TextChanged(System::Object^ sender, System::EventArgs^ e) {

}
private: System::Void ManagerLoginForm_Load(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void buttonManagerLogin_Click(System::Object^ sender, System::EventArgs^ e) {


	if (textBoxManagerUsername->Text == userName && textBoxManagerPassword->Text == password)
	{
		MessageBox::Show("Login Successful");

		ManagerHomePage manager;
		this->Hide();            //Hide the ManagerLoginForm Page
		manager.ShowDialog();    // Show the ManagerHomePage
		

	}
	else if (textBoxManagerUsername->Text != userName || textBoxManagerPassword->Text != password)
	{
		MessageBox::Show("Login Failed");
	}
}
};
}
