#pragma once

namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for ManagerPage
	/// </summary>
	public ref class ManagerPage : public System::Windows::Forms::Form
	{
	public:
		ManagerPage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ManagerPage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	protected:
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label4;
	private: System::Windows::Forms::Label^ label5;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeName;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeId;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeMobileNumber;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeDesignation;
	private: System::Windows::Forms::TextBox^ textBoxEmployeeDepartment;
	private: System::Windows::Forms::Label^ label6;
	private: System::Windows::Forms::ComboBox^ comboBoxEmployeeGender;
	private: System::Windows::Forms::Button^ buttonManagerPageSubmit;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ button1;









	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(ManagerPage::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBoxEmployeeName = (gcnew System::Windows::Forms::TextBox());
			this->textBoxEmployeeId = (gcnew System::Windows::Forms::TextBox());
			this->textBoxEmployeeMobileNumber = (gcnew System::Windows::Forms::TextBox());
			this->textBoxEmployeeDesignation = (gcnew System::Windows::Forms::TextBox());
			this->textBoxEmployeeDepartment = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->comboBoxEmployeeGender = (gcnew System::Windows::Forms::ComboBox());
			this->buttonManagerPageSubmit = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(77, 117);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(108, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Employee Name";
			this->label1->Click += gcnew System::EventHandler(this, &ManagerPage::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(77, 148);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(87, 16);
			this->label2->TabIndex = 1;
			this->label2->Text = L"Employee ID";
			this->label2->Click += gcnew System::EventHandler(this, &ManagerPage::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(77, 207);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(104, 16);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Mobile Number";
			this->label3->Click += gcnew System::EventHandler(this, &ManagerPage::label3_Click);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->Location = System::Drawing::Point(77, 235);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(80, 16);
			this->label4->TabIndex = 3;
			this->label4->Text = L"Designation";
			this->label4->Click += gcnew System::EventHandler(this, &ManagerPage::label4_Click);
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->Location = System::Drawing::Point(76, 265);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(81, 16);
			this->label5->TabIndex = 4;
			this->label5->Text = L"Department";
			this->label5->Click += gcnew System::EventHandler(this, &ManagerPage::label5_Click);
			// 
			// textBoxEmployeeName
			// 
			this->textBoxEmployeeName->Location = System::Drawing::Point(252, 114);
			this->textBoxEmployeeName->Name = L"textBoxEmployeeName";
			this->textBoxEmployeeName->Size = System::Drawing::Size(189, 20);
			this->textBoxEmployeeName->TabIndex = 5;
			this->textBoxEmployeeName->TextChanged += gcnew System::EventHandler(this, &ManagerPage::textBoxEmployeeName_TextChanged);
			// 
			// textBoxEmployeeId
			// 
			this->textBoxEmployeeId->Location = System::Drawing::Point(252, 145);
			this->textBoxEmployeeId->Name = L"textBoxEmployeeId";
			this->textBoxEmployeeId->Size = System::Drawing::Size(189, 20);
			this->textBoxEmployeeId->TabIndex = 6;
			this->textBoxEmployeeId->TextChanged += gcnew System::EventHandler(this, &ManagerPage::textBoxEmployeeId_TextChanged);
			// 
			// textBoxEmployeeMobileNumber
			// 
			this->textBoxEmployeeMobileNumber->Location = System::Drawing::Point(252, 207);
			this->textBoxEmployeeMobileNumber->Name = L"textBoxEmployeeMobileNumber";
			this->textBoxEmployeeMobileNumber->Size = System::Drawing::Size(189, 20);
			this->textBoxEmployeeMobileNumber->TabIndex = 7;
			this->textBoxEmployeeMobileNumber->TextChanged += gcnew System::EventHandler(this, &ManagerPage::textBoxEmployeeMobileNumber_TextChanged);
			// 
			// textBoxEmployeeDesignation
			// 
			this->textBoxEmployeeDesignation->Location = System::Drawing::Point(252, 236);
			this->textBoxEmployeeDesignation->Name = L"textBoxEmployeeDesignation";
			this->textBoxEmployeeDesignation->Size = System::Drawing::Size(189, 20);
			this->textBoxEmployeeDesignation->TabIndex = 8;
			this->textBoxEmployeeDesignation->TextChanged += gcnew System::EventHandler(this, &ManagerPage::textBoxEmployeeDesignation_TextChanged);
			// 
			// textBoxEmployeeDepartment
			// 
			this->textBoxEmployeeDepartment->Location = System::Drawing::Point(252, 266);
			this->textBoxEmployeeDepartment->Name = L"textBoxEmployeeDepartment";
			this->textBoxEmployeeDepartment->Size = System::Drawing::Size(189, 20);
			this->textBoxEmployeeDepartment->TabIndex = 9;
			this->textBoxEmployeeDepartment->TextChanged += gcnew System::EventHandler(this, &ManagerPage::textBoxEmployeeDepartment_TextChanged);
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label6->Location = System::Drawing::Point(77, 178);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(52, 16);
			this->label6->TabIndex = 10;
			this->label6->Text = L"Gender";
			this->label6->Click += gcnew System::EventHandler(this, &ManagerPage::label6_Click);
			// 
			// comboBoxEmployeeGender
			// 
			this->comboBoxEmployeeGender->Font = (gcnew System::Drawing::Font(L"Georgia", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->comboBoxEmployeeGender->FormattingEnabled = true;
			this->comboBoxEmployeeGender->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"Male", L"Female" });
			this->comboBoxEmployeeGender->Location = System::Drawing::Point(252, 177);
			this->comboBoxEmployeeGender->Name = L"comboBoxEmployeeGender";
			this->comboBoxEmployeeGender->Size = System::Drawing::Size(189, 22);
			this->comboBoxEmployeeGender->TabIndex = 12;
			this->comboBoxEmployeeGender->SelectedIndexChanged += gcnew System::EventHandler(this, &ManagerPage::comboBox1_SelectedIndexChanged);
			// 
			// buttonManagerPageSubmit
			// 
			this->buttonManagerPageSubmit->BackColor = System::Drawing::SystemColors::Window;
			this->buttonManagerPageSubmit->Font = (gcnew System::Drawing::Font(L"Georgia", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonManagerPageSubmit->Location = System::Drawing::Point(297, 306);
			this->buttonManagerPageSubmit->Name = L"buttonManagerPageSubmit";
			this->buttonManagerPageSubmit->Size = System::Drawing::Size(89, 29);
			this->buttonManagerPageSubmit->TabIndex = 13;
			this->buttonManagerPageSubmit->Text = L"Submit";
			this->buttonManagerPageSubmit->UseVisualStyleBackColor = false;
			this->buttonManagerPageSubmit->Click += gcnew System::EventHandler(this, &ManagerPage::buttonManagerPageSubmit_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(192, 12);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(274, 69);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 14;
			this->pictureBox1->TabStop = false;
			// 
			// button1
			// 
			this->button1->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(12, 12);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(71, 36);
			this->button1->TabIndex = 15;
			this->button1->Text = L"Back";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &ManagerPage::button1_Click);
			// 
			// ManagerPage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::GradientActiveCaption;
			this->ClientSize = System::Drawing::Size(621, 391);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->buttonManagerPageSubmit);
			this->Controls->Add(this->comboBoxEmployeeGender);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->textBoxEmployeeDepartment);
			this->Controls->Add(this->textBoxEmployeeDesignation);
			this->Controls->Add(this->textBoxEmployeeMobileNumber);
			this->Controls->Add(this->textBoxEmployeeId);
			this->Controls->Add(this->textBoxEmployeeName);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Name = L"ManagerPage";
			this->Text = L"ManagerPage";
			this->Load += gcnew System::EventHandler(this, &ManagerPage::ManagerPage_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void ManagerPage_Load(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxEmployeeId_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxEmployeeMobileNumber_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxEmployeeName_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxEmployeeDesignation_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxEmployeeDepartment_TextChanged(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label3_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label4_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void label5_Click(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void comboBox1_SelectedIndexChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label6_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void buttonManagerPageSubmit_Click(System::Object^ sender, System::EventArgs^ e) {

	MessageBox::Show("Employee Added");
}


private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Close();
}
};
}
