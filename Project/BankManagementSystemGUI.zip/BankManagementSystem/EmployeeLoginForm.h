#pragma once
#include "EmployeeHomePage.h"
namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for EmployeeLoginForm
	/// </summary>
	public ref class EmployeeLoginForm : public System::Windows::Forms::Form
	{
	public:
		EmployeeLoginForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~EmployeeLoginForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ buttonEmployeeLogin;
	protected:

	private: System::Windows::Forms::TextBox^ textBoxEmployeePassword;
	protected:

	private: System::Windows::Forms::TextBox^ textBoxEmployeeUsername;

	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::PictureBox^ pictureBox1;

	private:

		String^ userName = "employee";
		String^ password = "employee123";
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(EmployeeLoginForm::typeid));
			this->buttonEmployeeLogin = (gcnew System::Windows::Forms::Button());
			this->textBoxEmployeePassword = (gcnew System::Windows::Forms::TextBox());
			this->textBoxEmployeeUsername = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// buttonEmployeeLogin
			// 
			this->buttonEmployeeLogin->BackColor = System::Drawing::SystemColors::ScrollBar;
			this->buttonEmployeeLogin->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonEmployeeLogin->Location = System::Drawing::Point(182, 219);
			this->buttonEmployeeLogin->Name = L"buttonEmployeeLogin";
			this->buttonEmployeeLogin->Size = System::Drawing::Size(65, 26);
			this->buttonEmployeeLogin->TabIndex = 14;
			this->buttonEmployeeLogin->Text = L"Login";
			this->buttonEmployeeLogin->UseVisualStyleBackColor = false;
			this->buttonEmployeeLogin->Click += gcnew System::EventHandler(this, &EmployeeLoginForm::buttonEmployeeLogin_Click);
			// 
			// textBoxEmployeePassword
			// 
			this->textBoxEmployeePassword->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->textBoxEmployeePassword->Location = System::Drawing::Point(168, 177);
			this->textBoxEmployeePassword->Name = L"textBoxEmployeePassword";
			this->textBoxEmployeePassword->PasswordChar = '*';
			this->textBoxEmployeePassword->Size = System::Drawing::Size(140, 20);
			this->textBoxEmployeePassword->TabIndex = 13;
			this->textBoxEmployeePassword->TextChanged += gcnew System::EventHandler(this, &EmployeeLoginForm::textBoxEmployeePassword_TextChanged);
			// 
			// textBoxEmployeeUsername
			// 
			this->textBoxEmployeeUsername->BackColor = System::Drawing::SystemColors::ButtonHighlight;
			this->textBoxEmployeeUsername->Location = System::Drawing::Point(168, 137);
			this->textBoxEmployeeUsername->Name = L"textBoxEmployeeUsername";
			this->textBoxEmployeeUsername->Size = System::Drawing::Size(140, 20);
			this->textBoxEmployeeUsername->TabIndex = 12;
			this->textBoxEmployeeUsername->TextChanged += gcnew System::EventHandler(this, &EmployeeLoginForm::textBoxManagerUsername_TextChanged);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->Location = System::Drawing::Point(68, 177);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(73, 16);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Password :";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(68, 141);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(82, 16);
			this->label2->TabIndex = 10;
			this->label2->Text = L"User Name :";
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(-5, 3);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(419, 84);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 9;
			this->pictureBox1->TabStop = false;
			// 
			// EmployeeLoginForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(410, 328);
			this->Controls->Add(this->buttonEmployeeLogin);
			this->Controls->Add(this->textBoxEmployeePassword);
			this->Controls->Add(this->textBoxEmployeeUsername);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->pictureBox1);
			this->Name = L"EmployeeLoginForm";
			this->Text = L"EmployeeLoginForm";
			this->Load += gcnew System::EventHandler(this, &EmployeeLoginForm::EmployeeLoginForm_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void EmployeeLoginForm_Load(System::Object^ sender, System::EventArgs^ e) {
	}
private: System::Void textBoxManagerUsername_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void buttonEmployeeLogin_Click(System::Object^ sender, System::EventArgs^ e) {

	if (textBoxEmployeeUsername->Text == userName && textBoxEmployeePassword->Text == password)
	{
		MessageBox::Show("Login Successful");

		EmployeeHomePage employee;
		this->Hide();            //Hide the EmployeeLoginForm Page
		employee.ShowDialog();    // Show the EmployeeHomePage


	}
	else if (textBoxEmployeeUsername->Text != userName || textBoxEmployeePassword->Text != password)
	{
		MessageBox::Show("Login Failed");
	}
}
private: System::Void textBoxEmployeePassword_TextChanged(System::Object^ sender, System::EventArgs^ e) {
}
};
}
