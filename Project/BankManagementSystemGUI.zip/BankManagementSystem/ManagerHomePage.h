#pragma once
#include "ManagerPage.h"
#include "ManagerSearchEmployee.h"
namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for ManagerHomePage
	/// </summary>
	public ref class ManagerHomePage : public System::Windows::Forms::Form
	{
	public:
		ManagerHomePage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~ManagerHomePage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ buttonEmployeeAdd;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Button^ buttonEmployeeSearch;








	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(ManagerHomePage::typeid));
			this->buttonEmployeeAdd = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->buttonEmployeeSearch = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// buttonEmployeeAdd
			// 
			this->buttonEmployeeAdd->BackColor = System::Drawing::Color::Silver;
			this->buttonEmployeeAdd->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonEmployeeAdd->Location = System::Drawing::Point(98, 141);
			this->buttonEmployeeAdd->Name = L"buttonEmployeeAdd";
			this->buttonEmployeeAdd->Size = System::Drawing::Size(182, 48);
			this->buttonEmployeeAdd->TabIndex = 0;
			this->buttonEmployeeAdd->Text = L"Add New Employee";
			this->buttonEmployeeAdd->UseVisualStyleBackColor = false;
			this->buttonEmployeeAdd->Click += gcnew System::EventHandler(this, &ManagerHomePage::buttonEmployeeAdd_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(-3, -2);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(386, 71);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 3;
			this->pictureBox1->TabStop = false;
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button1->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(295, 285);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 39);
			this->button1->TabIndex = 4;
			this->button1->Text = L"Logout";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &ManagerHomePage::button1_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(151, 86);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(84, 18);
			this->label1->TabIndex = 5;
			this->label1->Text = L"HomePage";
			this->label1->Click += gcnew System::EventHandler(this, &ManagerHomePage::label1_Click);
			// 
			// buttonEmployeeSearch
			// 
			this->buttonEmployeeSearch->BackColor = System::Drawing::Color::Silver;
			this->buttonEmployeeSearch->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonEmployeeSearch->Location = System::Drawing::Point(98, 195);
			this->buttonEmployeeSearch->Name = L"buttonEmployeeSearch";
			this->buttonEmployeeSearch->Size = System::Drawing::Size(182, 48);
			this->buttonEmployeeSearch->TabIndex = 6;
			this->buttonEmployeeSearch->Text = L"Search Employee";
			this->buttonEmployeeSearch->UseVisualStyleBackColor = false;
			this->buttonEmployeeSearch->Click += gcnew System::EventHandler(this, &ManagerHomePage::buttonEmployeeSearch_Click);
			// 
			// ManagerHomePage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(382, 336);
			this->Controls->Add(this->buttonEmployeeSearch);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->buttonEmployeeAdd);
			this->Name = L"ManagerHomePage";
			this->Text = L"ManagerHomePage";
			this->Load += gcnew System::EventHandler(this, &ManagerHomePage::ManagerHomePage_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void buttonEmployeeAdd_Click(System::Object^ sender, System::EventArgs^ e) {

		ManagerPage manager;
		this->Hide();
		manager.ShowDialog();
		this->Show();
	}
	private: System::Void maskedTextBox1_MaskInputRejected(System::Object^ sender, System::Windows::Forms::MaskInputRejectedEventArgs^ e) {
	}
private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

	this->Close();
	MessageBox::Show("Logout Successfully");
}
private: System::Void label2_Click(System::Object^ sender, System::EventArgs^ e) {
}
private: System::Void label1_Click(System::Object^ sender, System::EventArgs^ e) {
}

private: System::Void buttonEmployeeSearch_Click(System::Object^ sender, System::EventArgs^ e) {
	this->Hide();
	ManagerSearchEmployee manager;
	manager.ShowDialog();
	this->Show();
	
}
private: System::Void ManagerHomePage_Load(System::Object^ sender, System::EventArgs^ e) {
}
};
}
