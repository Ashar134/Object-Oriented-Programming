#include "Loginform.h"
#include<Windows.h>
using namespace BankManagementSystem;


int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Application::Run(gcnew Loginform());

}
