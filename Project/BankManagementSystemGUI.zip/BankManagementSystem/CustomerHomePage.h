#pragma once
#include "CustomerDepositAmount1.h"
#include "CustomerWithdrawAmount.h"
#include "CustomerMonthlyStatement.h"

namespace BankManagementSystem {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for CustomerHomePage
	/// </summary>
	public ref class CustomerHomePage : public System::Windows::Forms::Form
	{
	public:
		CustomerHomePage(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CustomerHomePage()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^ buttonCustomerMonthlyStatement;
	protected:

	private: System::Windows::Forms::Button^ buttonCustomerWithdraw;
	protected:

	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Button^ buttonCustomerDeposit;

	protected:






	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(CustomerHomePage::typeid));
			this->buttonCustomerMonthlyStatement = (gcnew System::Windows::Forms::Button());
			this->buttonCustomerWithdraw = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->buttonCustomerDeposit = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// buttonCustomerMonthlyStatement
			// 
			this->buttonCustomerMonthlyStatement->BackColor = System::Drawing::Color::Silver;
			this->buttonCustomerMonthlyStatement->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular,
				System::Drawing::GraphicsUnit::Point, static_cast<System::Byte>(0)));
			this->buttonCustomerMonthlyStatement->Location = System::Drawing::Point(127, 266);
			this->buttonCustomerMonthlyStatement->Name = L"buttonCustomerMonthlyStatement";
			this->buttonCustomerMonthlyStatement->Size = System::Drawing::Size(182, 48);
			this->buttonCustomerMonthlyStatement->TabIndex = 16;
			this->buttonCustomerMonthlyStatement->Text = L"Monthly Statement ";
			this->buttonCustomerMonthlyStatement->UseVisualStyleBackColor = false;
			this->buttonCustomerMonthlyStatement->Click += gcnew System::EventHandler(this, &CustomerHomePage::buttonCustomerMonthlyStatement_Click);
			// 
			// buttonCustomerWithdraw
			// 
			this->buttonCustomerWithdraw->BackColor = System::Drawing::Color::Silver;
			this->buttonCustomerWithdraw->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonCustomerWithdraw->Location = System::Drawing::Point(127, 212);
			this->buttonCustomerWithdraw->Name = L"buttonCustomerWithdraw";
			this->buttonCustomerWithdraw->Size = System::Drawing::Size(182, 48);
			this->buttonCustomerWithdraw->TabIndex = 15;
			this->buttonCustomerWithdraw->Text = L"WithDraw Amount";
			this->buttonCustomerWithdraw->UseVisualStyleBackColor = false;
			this->buttonCustomerWithdraw->Click += gcnew System::EventHandler(this, &CustomerHomePage::buttonCustomerWithdraw_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Georgia", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(192, 110);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(84, 18);
			this->label2->TabIndex = 14;
			this->label2->Text = L"HomePage";
			// 
			// button1
			// 
			this->button1->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(128)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->button1->Font = (gcnew System::Drawing::Font(L"Georgia", 9, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->button1->Location = System::Drawing::Point(347, 328);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(85, 32);
			this->button1->TabIndex = 13;
			this->button1->Text = L"Logout";
			this->button1->UseVisualStyleBackColor = false;
			this->button1->Click += gcnew System::EventHandler(this, &CustomerHomePage::button1_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(-6, 3);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(459, 82);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::StretchImage;
			this->pictureBox1->TabIndex = 12;
			this->pictureBox1->TabStop = false;
			// 
			// buttonCustomerDeposit
			// 
			this->buttonCustomerDeposit->BackColor = System::Drawing::Color::Silver;
			this->buttonCustomerDeposit->Font = (gcnew System::Drawing::Font(L"Georgia", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->buttonCustomerDeposit->Location = System::Drawing::Point(127, 158);
			this->buttonCustomerDeposit->Name = L"buttonCustomerDeposit";
			this->buttonCustomerDeposit->Size = System::Drawing::Size(182, 48);
			this->buttonCustomerDeposit->TabIndex = 11;
			this->buttonCustomerDeposit->Text = L"Deposit Amount";
			this->buttonCustomerDeposit->UseVisualStyleBackColor = false;
			this->buttonCustomerDeposit->Click += gcnew System::EventHandler(this, &CustomerHomePage::buttonCustomerDeposit_Click);
			// 
			// CustomerHomePage
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::SystemColors::ActiveCaption;
			this->ClientSize = System::Drawing::Size(454, 376);
			this->Controls->Add(this->buttonCustomerMonthlyStatement);
			this->Controls->Add(this->buttonCustomerWithdraw);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->buttonCustomerDeposit);
			this->Name = L"CustomerHomePage";
			this->Text = L"CustomerHomePage";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {

		this->Close();
	}
private: System::Void buttonCustomerDeposit_Click(System::Object^ sender, System::EventArgs^ e) {

	CustomerDepositAmount customer;
	customer.ShowDialog();
	this->Show();


}
private: System::Void buttonCustomerWithdraw_Click(System::Object^ sender, System::EventArgs^ e) {

	CustomerWithdrawAmount customer;
	customer.ShowDialog();
	this->Show();

}
private: System::Void buttonCustomerMonthlyStatement_Click(System::Object^ sender, System::EventArgs^ e) {

	CustomerMonthlyStatement customer;
	customer.ShowDialog();
	this->Show();
}
};
}
